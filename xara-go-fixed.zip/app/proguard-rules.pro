# Shizuku rules
-keep class dev.rikka.shizuku.** { *; }
-dontwarn dev.rikka.shizuku.**

# Compose rules
-keepclassmembers class * extends androidx.compose.runtime.State { *; }
