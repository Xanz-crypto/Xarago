package com.xara.go.ai

import com.xara.go.hardware.BatteryInfo
import com.xara.go.hardware.RamInfo
import com.xara.go.shizuku.ShizukuManager

enum class PerformanceProfile(val displayName: String, val badgeColor: Long) {
    STANDAR("Standar", 0xFF94A3B8),
    PERFORMA("Performa", 0xFF00E5FF),
    HEMAT("Hemat Baterai", 0xFF10B981)
}

data class DecisionResult(
    val profile: PerformanceProfile,
    val headline: String,
    val reasonIndonesian: String,
    val targetRefreshRate: Int?,
    val targetAnimationScale: Float,
    val gameModeCommand: String,
    val thermalWarning: Boolean
)

class PerformanceEngine {

    /**
     * Mesin inferensi aturan deterministik lokal di dalam perangkat (Edge Rule-Engine).
     * Bekerja 100% offline tanpa koneksi internet atau API key eksternal.
     */
    fun evaluateRules(
        battery: BatteryInfo,
        ram: RamInfo,
        supportedRefreshRates: List<Int>,
        activeGamePackage: String? = null
    ): DecisionResult {
        val temp = battery.temperatureC
        val batteryPct = battery.percentage
        val isCharging = battery.isCharging
        val ramUsedPct = ram.percentUsed

        val maxRate = supportedRefreshRates.maxOrNull() ?: 60
        val minRate = supportedRefreshRates.minOrNull() ?: 60

        // Aturan 1: Perlindungan Thermal Kritis (Suhu >= 43°C atau Severe Thermal)
        if (temp >= 43.0f || battery.thermalStatusText.contains("Throttling") || battery.thermalStatusText.contains("Kritis")) {
            return DecisionResult(
                profile = PerformanceProfile.HEMAT,
                headline = "Pencegahan Overheat Ekstrem",
                reasonIndonesian = "Suhu baterai mencapai ${String.format("%.1f", temp)}°C (melebihi ambang batas aman 42°C). Profil dialihkan ke Hemat untuk mendinginkan SoC dan mencegah thermal throttling mendadak.",
                targetRefreshRate = minRate,
                targetAnimationScale = 1.0f,
                gameModeCommand = "battery",
                thermalWarning = true
            )
        }

        // Aturan 2: Suhu Mendekati Throttling (40°C - 42.9°C)
        if (temp >= 40.0f) {
            return DecisionResult(
                profile = PerformanceProfile.STANDAR,
                headline = "Stabilisasi Suhu & Frame Rate",
                reasonIndonesian = "Suhu berada pada ${String.format("%.1f", temp)}°C. Profil distabilkan ke Standar untuk mencegah kenaikan suhu ke zona bahaya selagi mempertahankan kelancaran bermain.",
                targetRefreshRate = if (supportedRefreshRates.contains(90)) 90 else minRate,
                targetAnimationScale = 0.5f,
                gameModeCommand = "standard",
                thermalWarning = false
            )
        }

        // Aturan 3: Baterai Rendah (< 20%) & Tidak Sedang Mengisi
        if (batteryPct <= 20 && !isCharging) {
            return DecisionResult(
                profile = PerformanceProfile.HEMAT,
                headline = "Penghematan Daya Kritis",
                reasonIndonesian = "Daya baterai tersisa $batteryPct% tanpa terhubung charger. Sistem membatasi refresh rate ke $minRate Hz dan governor hemat energi agar sesi bermain bertahan lebih lama.",
                targetRefreshRate = minRate,
                targetAnimationScale = 1.0f,
                gameModeCommand = "battery",
                thermalWarning = false
            )
        }

        // Aturan 4: Kondisi Dingin/Optimal (< 38°C) + Baterai Cukup (> 25% atau sedang di-charge)
        if (temp < 38.5f && (batteryPct > 25 || isCharging)) {
            val boostRate = if (supportedRefreshRates.contains(120)) 120 else if (supportedRefreshRates.contains(90)) 90 else maxRate
            return DecisionResult(
                profile = PerformanceProfile.PERFORMA,
                headline = "Daya Penuh & Refresh Rate Maksimal",
                reasonIndonesian = "Hardware dalam kondisi prima (Suhu ${String.format("%.1f", temp)}°C, RAM terpakai $ramUsedPct%). Profil Performa diaktifkan dengan animasi dipangkas ke 0.0x dan Game Mode Performance.",
                targetRefreshRate = boostRate,
                targetAnimationScale = 0.0f,
                gameModeCommand = "performance",
                thermalWarning = false
            )
        }

        // Aturan Default: Standar Seimbang
        return DecisionResult(
            profile = PerformanceProfile.STANDAR,
            headline = "Keseimbangan Efisiensi & Respons",
            reasonIndonesian = "Suhu normal (${String.format("%.1f", temp)}°C) dan daya mencukupi ($batteryPct%). Profil Standar menjaga fps stabil tanpa konsumsi daya berlebih.",
            targetRefreshRate = 60,
            targetAnimationScale = 0.5f,
            gameModeCommand = "standard",
            thermalWarning = false
        )
    }

    suspend fun applyDecision(
        decision: DecisionResult,
        shizukuManager: ShizukuManager,
        gamePackage: String?
    ): Boolean {
        // Terapkan animasi sistem
        shizukuManager.setAnimationScales(decision.targetAnimationScale)

        // Terapkan refresh rate jika didukung
        decision.targetRefreshRate?.let {
            shizukuManager.setRefreshRate(it.toFloat())
        }

        // Terapkan Game Mode jika ada paket game aktif
        if (!gamePackage.isNullOrEmpty()) {
            shizukuManager.setGameMode(gamePackage, decision.gameModeCommand)
        }

        return true
    }
}
