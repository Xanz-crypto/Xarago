package com.xara.go.hardware

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.view.Display
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.io.RandomAccessFile
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.roundToInt

data class RamInfo(
    val totalBytes: Long,
    val availBytes: Long,
    val usedBytes: Long,
    val percentUsed: Int,
    val formattedTotal: String,
    val formattedUsed: String,
    val formattedAvail: String
)

data class BatteryInfo(
    val percentage: Int,
    val temperatureC: Float,
    val voltageV: Float,
    val currentNowMa: Int?, // Arus keluar/masuk dalam mA, null jika tidak didukung
    val healthText: String,
    val isCharging: Boolean,
    val chargingSourceText: String, // AC, USB, Wireless, atau "Tidak sedang mengisi"
    val thermalStatusText: String
)

data class HardwareSpecs(
    val model: String,
    val manufacturer: String,
    val board: String,
    val soc: String,
    val androidVersion: String,
    val sdkInt: Int,
    val supportedRefreshRates: List<Int>,
    val currentRefreshRate: Int
)

class HardwareMonitor(private val context: Context) {

    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    private val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager

    private val monitorScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private val _ramState = MutableStateFlow(getRealRamInfo())
    val ramState: StateFlow<RamInfo> = _ramState

    private val _batteryState = MutableStateFlow(getRealBatteryInfo(null))
    val batteryState: StateFlow<BatteryInfo> = _batteryState

    private val _cpuFrequencyGhz = MutableStateFlow<String>("Memuat...")
    val cpuFrequencyGhz: StateFlow<String> = _cpuFrequencyGhz

    private val _pingMs = MutableStateFlow<Int?>(null)
    val pingMs: StateFlow<Int?> = _pingMs

    val hardwareSpecs: HardwareSpecs by lazy {
        detectHardwareSpecs()
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, intent: Intent?) {
            _batteryState.value = getRealBatteryInfo(intent)
        }
    }

    init {
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val initialIntent = context.registerReceiver(batteryReceiver, filter)
        _batteryState.value = getRealBatteryInfo(initialIntent)

        startPeriodicMonitor()
    }

    private fun startPeriodicMonitor() {
        monitorScope.launch {
            while (isActive) {
                _ramState.value = getRealRamInfo()
                _cpuFrequencyGhz.value = readRealCpuFrequency()
                _pingMs.value = measureRealPing()
                delay(2000)
            }
        }
    }

    // 1. RAM ASLI dari ActivityManager.MemoryInfo
    fun getRealRamInfo(): RamInfo {
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)

        val total = memoryInfo.totalMem
        val avail = memoryInfo.availMem
        val used = total - avail
        val percent = if (total > 0) ((used.toDouble() / total) * 100).toInt() else 0

        fun formatGb(bytes: Long): String {
            val gb = bytes.toDouble() / (1024 * 1024 * 1024)
            return String.format("%.1f GB", gb).replace('.', ',')
        }

        return RamInfo(
            totalBytes = total,
            availBytes = avail,
            usedBytes = used,
            percentUsed = percent,
            formattedTotal = formatGb(total),
            formattedUsed = formatGb(used),
            formattedAvail = formatGb(avail)
        )
    }

    // 2. Baterai & Suhu Asli dari BatteryManager
    private fun getRealBatteryInfo(intent: Intent?): BatteryInfo {
        val batteryIntent = intent ?: context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) ((level.toFloat() / scale) * 100).roundToInt() else 0

        val tempRaw = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val tempC = if (tempRaw > 0) tempRaw / 10.0f else 0.0f

        val voltRaw = batteryIntent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val voltV = if (voltRaw > 0) voltRaw / 1000.0f else 0.0f

        val health = batteryIntent?.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
        val healthText = when (health) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Baik"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Terlalu Panas"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Mati"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Tegangan Lebih"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Gagal"
            BatteryManager.BATTERY_HEALTH_COLD -> "Dingin"
            else -> "Baik"
        }

        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL

        val plugged = batteryIntent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val chargingSourceText = when (plugged) {
            BatteryManager.BATTERY_PLUGGED_AC -> "Charger AC"
            BatteryManager.BATTERY_PLUGGED_USB -> "Port USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Nirkabel"
            else -> "Tidak sedang mengisi"
        }

        val currentNow = try {
            val microAmps = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
            if (microAmps != Int.MIN_VALUE && microAmps != 0) {
                microAmps / 1000
            } else null
        } catch (_: Exception) {
            null
        }

        val thermalStatusText = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            when (powerManager.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "Normal"
                PowerManager.THERMAL_STATUS_LIGHT -> "Hangat"
                PowerManager.THERMAL_STATUS_MODERATE -> "Sedang"
                PowerManager.THERMAL_STATUS_SEVERE -> "Tinggi (Throttling)"
                PowerManager.THERMAL_STATUS_CRITICAL -> "Kritis"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "Darurat"
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "Mati Otomatis"
                else -> "Normal"
            }
        } else {
            if (tempC >= 45.0f) "Tinggi" else if (tempC >= 40.0f) "Sedang" else "Normal"
        }

        return BatteryInfo(
            percentage = pct,
            temperatureC = tempC,
            voltageV = voltV,
            currentNowMa = currentNow,
            healthText = healthText,
            isCharging = isCharging,
            chargingSourceText = chargingSourceText,
            thermalStatusText = thermalStatusText
        )
    }

    // 3. Hardware Specs Asli dari Build & Display
    private fun detectHardwareSpecs(): HardwareSpecs {
        val defaultDisplay = displayManager.getDisplay(Display.DEFAULT_DISPLAY)
        val supportedRates = defaultDisplay?.supportedModes?.map { it.refreshRate.roundToInt() }?.distinct()?.sorted() ?: listOf(60)
        val currentRate = defaultDisplay?.mode?.refreshRate?.roundToInt() ?: 60

        val soc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Build.SOC_MODEL.ifEmpty { Build.HARDWARE }
        } else {
            Build.HARDWARE
        }

        return HardwareSpecs(
            model = Build.MODEL,
            manufacturer = Build.MANUFACTURER,
            board = Build.BOARD,
            soc = soc,
            androidVersion = Build.VERSION.RELEASE,
            sdkInt = Build.VERSION.SDK_INT,
            supportedRefreshRates = supportedRates,
            currentRefreshRate = currentRate
        )
    }

    // 4. Pembacaan CPU Asli dari sysfs
    private fun readRealCpuFrequency(): String {
        return try {
            val file = File("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq")
            if (file.exists() && file.canRead()) {
                val reader = RandomAccessFile(file, "r")
                val line = reader.readLine()
                reader.close()
                val khz = line.toLongOrNull()
                if (khz != null) {
                    val ghz = khz.toDouble() / 1_000_000
                    return String.format("%.2f GHz", ghz)
                }
            }
            // Fallback: core count
            val cores = Runtime.getRuntime().availableProcessors()
            "${cores} Cores Aktif"
        } catch (_: Exception) {
            "Tidak didukung"
        }
    }

    // 5. Pengukuran Ping Nyata via Socket
    private suspend fun measureRealPing(): Int? = withContext(Dispatchers.IO) {
        try {
            val startTime = System.currentTimeMillis()
            val socket = Socket()
            socket.connect(InetSocketAddress("8.8.8.8", 53), 1500)
            val latency = (System.currentTimeMillis() - startTime).toInt()
            socket.close()
            latency
        } catch (_: Exception) {
            null
        }
    }

    // 6. Pembersihan RAM Nyata
    suspend fun performRealRamClean(onProcessKill: (suspend (String) -> Unit)? = null): Pair<RamInfo, RamInfo> = withContext(Dispatchers.IO) {
        val before = getRealRamInfo()

        // 1. Bersihkan background cache via Android API resmi
        val runningProcesses = activityManager.runningAppProcesses ?: emptyList()
        val myPkg = context.packageName

        for (proc in runningProcesses) {
            if (proc.pkgList != null) {
                for (pkg in proc.pkgList) {
                    if (pkg != myPkg && !isSystemCore(pkg)) {
                        activityManager.killBackgroundProcesses(pkg)
                        onProcessKill?.invoke(pkg)
                    }
                }
            }
        }

        // Panggil garbage collector JVM
        System.gc()
        delay(800)

        val after = getRealRamInfo()
        _ramState.value = after
        Pair(before, after)
    }

    private fun isSystemCore(pkg: String): Boolean {
        return pkg.startsWith("com.android.systemui") ||
               pkg.startsWith("com.google.android.inputmethod") ||
               pkg.contains("launcher") ||
               pkg == "moe.shizuku.privileged.api" ||
               pkg == "dev.rikka.shizuku"
    }
}
