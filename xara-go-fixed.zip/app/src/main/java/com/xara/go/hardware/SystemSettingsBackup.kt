package com.xara.go.hardware

import android.content.Context
import android.provider.Settings
import com.xara.go.shizuku.ShizukuManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class BackupState(
    val windowAnimScale: Float,
    val transitionAnimScale: Float,
    val animatorDurationScale: Float,
    val peakRefreshRate: Float?,
    val minRefreshRate: Float?,
    val timestamp: Long
)

class SystemSettingsBackup(private val context: Context) {

    private val prefs = context.getSharedPreferences("xara_system_backup", Context.MODE_PRIVATE)

    fun backupDefaultsIfNeeded() {
        if (!prefs.contains(KEY_BACKUP_EXISTS)) {
            val windowAnim = getGlobalFloat(Settings.Global.WINDOW_ANIMATION_SCALE, 1.0f)
            val transAnim = getGlobalFloat(Settings.Global.TRANSITION_ANIMATION_SCALE, 1.0f)
            val durationAnim = getGlobalFloat(Settings.Global.ANIMATOR_DURATION_SCALE, 1.0f)

            val peakRefresh = getSystemFloat("peak_refresh_rate", -1f)
            val minRefresh = getSystemFloat("min_refresh_rate", -1f)

            prefs.edit()
                .putBoolean(KEY_BACKUP_EXISTS, true)
                .putFloat(KEY_WINDOW_ANIM, windowAnim)
                .putFloat(KEY_TRANS_ANIM, transAnim)
                .putFloat(KEY_DURATION_ANIM, durationAnim)
                .putFloat(KEY_PEAK_REFRESH, peakRefresh)
                .putFloat(KEY_MIN_REFRESH, minRefresh)
                .putLong(KEY_TIMESTAMP, System.currentTimeMillis())
                .apply()
        }
    }

    fun getBackup(): BackupState {
        return BackupState(
            windowAnimScale = prefs.getFloat(KEY_WINDOW_ANIM, 1.0f),
            transitionAnimScale = prefs.getFloat(KEY_TRANS_ANIM, 1.0f),
            animatorDurationScale = prefs.getFloat(KEY_DURATION_ANIM, 1.0f),
            peakRefreshRate = prefs.getFloat(KEY_PEAK_REFRESH, -1f).takeIf { it > 0 },
            minRefreshRate = prefs.getFloat(KEY_MIN_REFRESH, -1f).takeIf { it > 0 },
            timestamp = prefs.getLong(KEY_TIMESTAMP, 0L)
        )
    }

    suspend fun restoreToDefault(shizukuManager: ShizukuManager): Boolean = withContext(Dispatchers.IO) {
        val backup = getBackup()

        // 1. Kembalikan skala animasi bawaan pabrik HP
        shizukuManager.setAnimationScales(backup.windowAnimScale)

        // 2. Kembalikan refresh rate bawaan
        if (backup.peakRefreshRate != null && backup.peakRefreshRate > 0) {
            shizukuManager.setRefreshRate(backup.peakRefreshRate)
        } else {
            // Hapus paksaan refresh rate agar sistem otomatis mengelola
            shizukuManager.executeCommand("settings delete system peak_refresh_rate && settings delete system min_refresh_rate")
        }

        // 3. Reset Android Game Mode ke standar jika didukung
        shizukuManager.executeCommand("cmd game mode standard all")

        true
    }

    private fun getGlobalFloat(name: String, def: Float): Float {
        return try {
            Settings.Global.getFloat(context.contentResolver, name, def)
        } catch (_: Exception) {
            def
        }
    }

    private fun getSystemFloat(name: String, def: Float): Float {
        return try {
            Settings.System.getFloat(context.contentResolver, name, def)
        } catch (_: Exception) {
            def
        }
    }

    companion object {
        private const val KEY_BACKUP_EXISTS = "backup_exists"
        private const val KEY_WINDOW_ANIM = "window_anim"
        private const val KEY_TRANS_ANIM = "trans_anim"
        private const val KEY_DURATION_ANIM = "duration_anim"
        private const val KEY_PEAK_REFRESH = "peak_refresh"
        private const val KEY_MIN_REFRESH = "min_refresh"
        private const val KEY_TIMESTAMP = "backup_timestamp"
    }
}
