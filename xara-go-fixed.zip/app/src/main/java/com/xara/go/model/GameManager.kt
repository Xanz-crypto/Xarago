package com.xara.go.model

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import com.xara.go.shizuku.ShizukuManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class GameManager(private val context: Context) {

    private val packageManager = context.packageManager
    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val prefs = context.getSharedPreferences("xara_game_prefs", Context.MODE_PRIVATE)

    // Paket-paket inti yang DILARANG KERAS dihentikan demi stabilitas sistem
    private val coreSystemWhitelist = setOf(
        context.packageName,
        "com.android.systemui",
        "moe.shizuku.privileged.api",
        "dev.rikka.shizuku"
    )

    fun getUserWhitelist(): Set<String> {
        return prefs.getStringSet(KEY_WHITELIST, emptySet()) ?: emptySet()
    }

    fun setUserWhitelist(whitelist: Set<String>) {
        prefs.edit().putStringSet(KEY_WHITELIST, whitelist).apply()
    }

    fun toggleWhitelist(packageName: String) {
        val current = getUserWhitelist().toMutableSet()
        if (current.contains(packageName)) {
            current.remove(packageName)
        } else {
            current.add(packageName)
        }
        setUserWhitelist(current)
    }

    fun isProtectedFromKill(packageName: String): Boolean {
        // Cek apakah core system
        if (coreSystemWhitelist.contains(packageName)) return true
        // Cek launcher bawaan
        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val defaultLauncher = packageManager.resolveActivity(homeIntent, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        if (packageName == defaultLauncher) return true

        // Cek dialer
        val dialerIntent = Intent(Intent.ACTION_DIAL)
        val defaultDialer = packageManager.resolveActivity(dialerIntent, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        if (packageName == defaultDialer) return true

        // Cek keyboard/IME
        val currentIme = android.provider.Settings.Secure.getString(context.contentResolver, android.provider.Settings.Secure.DEFAULT_INPUT_METHOD)
        if (currentIme != null && currentIme.contains(packageName)) return true

        // Cek daftar putih pilihan pengguna
        return getUserWhitelist().contains(packageName)
    }

    // Mendeteksi game terpasang di HP secara otomatis
    suspend fun getInstalledGames(): List<InstalledGame> = withContext(Dispatchers.IO) {
        val games = mutableListOf<InstalledGame>()
        val packages = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)

        val knownGameKeywords = listOf("game", "unity", "unreal", "freefire", "dts.freefire", "mobilelegends", "pubg", "genshin", "codm", "roblox", "honkai")

        for (app in packages) {
            val isCategoryGame = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                app.category == ApplicationInfo.CATEGORY_GAME
            } else {
                (app.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            }

            val pkgLower = app.packageName.lowercase()
            val matchesKeyword = knownGameKeywords.any { pkgLower.contains(it) }

            // Jangan masukkan aplikasi sendiri atau launcher
            if (app.packageName == context.packageName) continue

            if (isCategoryGame || matchesKeyword) {
                val label = try {
                    packageManager.getApplicationLabel(app).toString()
                } catch (_: Exception) {
                    app.packageName
                }
                val icon = try {
                    packageManager.getApplicationIcon(app)
                } catch (_: Exception) {
                    null
                }

                games.add(
                    InstalledGame(
                        packageName = app.packageName,
                        appName = label,
                        icon = icon,
                        playedTimeMinutes = getSavedPlaytimeMinutes(app.packageName),
                        isCustomMode = true
                    )
                )
            }
        }

        // Jika HP tidak memiliki game terpasang, sediakan placeholder game terdaftar untuk pengujian
        if (games.isEmpty()) {
            games.add(
                InstalledGame(
                    packageName = "com.dts.freefireth",
                    appName = "Free Fire",
                    icon = null,
                    playedTimeMinutes = 196,
                    isCustomMode = true
                )
            )
            games.add(
                InstalledGame(
                    packageName = "com.mobile.legends",
                    appName = "Mobile Legends: Bang Bang",
                    icon = null,
                    playedTimeMinutes = 573,
                    isCustomMode = true
                )
            )
        }

        games
    }

    // Mendeteksi aplikasi berat yang sedang berjalan di latar belakang beserta penggunaan RAM asli
    suspend fun getRunningBackgroundApps(): List<BackgroundApp> = withContext(Dispatchers.IO) {
        val list = mutableListOf<BackgroundApp>()
        val runningProcesses = activityManager.runningAppProcesses ?: return@withContext list

        val pids = runningProcesses.map { it.pid }.toIntArray()
        val memInfos = activityManager.getProcessMemoryInfo(pids)

        for (i in runningProcesses.indices) {
            val proc = runningProcesses[i]
            val memInfo = memInfos.getOrNull(i)
            val memMb = ((memInfo?.totalPss ?: 0) / 1024)

            // Lewati proses Xara Go sendiri
            if (proc.pid == Process.myPid()) continue

            val pkg = proc.pkgList?.firstOrNull() ?: continue
            val isWhitelisted = isProtectedFromKill(pkg)

            // Hanya tampilkan jika menggunakan RAM signifikan (> 10MB)
            if (memMb > 10) {
                val label = try {
                    val appInfo = packageManager.getApplicationInfo(pkg, 0)
                    packageManager.getApplicationLabel(appInfo).toString()
                } catch (_: Exception) {
                    pkg
                }

                val icon = try {
                    packageManager.getApplicationIcon(pkg)
                } catch (_: Exception) {
                    null
                }

                val isSystem = try {
                    val appInfo = packageManager.getApplicationInfo(pkg, 0)
                    (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                } catch (_: Exception) {
                    false
                }

                list.add(
                    BackgroundApp(
                        packageName = pkg,
                        appName = label,
                        memoryUsageMb = memMb,
                        isSystem = isSystem,
                        isWhitelisted = isWhitelisted,
                        icon = icon
                    )
                )
            }
        }

        list.sortedByDescending { it.memoryUsageMb }
    }

    // Hentikan otomatis semua aplikasi latar belakang non-whitelist saat game dibuka
    suspend fun autoCleanForGameLaunch(shizukuManager: ShizukuManager): Int = withContext(Dispatchers.IO) {
        var killedCount = 0
        val apps = getRunningBackgroundApps()
        for (app in apps) {
            if (!app.isWhitelisted) {
                // Gunakan Shizuku/root am force-stop
                val res = shizukuManager.forceStopApp(app.packageName)
                if (res.success) {
                    killedCount++
                } else {
                    // Fallback Android killBackgroundProcesses
                    activityManager.killBackgroundProcesses(app.packageName)
                }
            }
        }
        killedCount
    }

    private fun getSavedPlaytimeMinutes(pkg: String): Long {
        return prefs.getLong("playtime_$pkg", 0L)
    }

    fun launchGame(packageName: String) {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
        }
    }

    companion object {
        private const val KEY_WHITELIST = "user_whitelist_packages"
    }
}
