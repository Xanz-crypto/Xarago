package com.xara.go.ui.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xara.go.hardware.BatteryInfo
import com.xara.go.hardware.RamInfo
import com.xara.go.ui.theme.*

data class HudFeature(
    val id: String,
    val name: String,
    val icon: ImageVector,
    val isInstalled: Boolean = true,
    val isActive: Boolean = false
)

@Composable
fun GamePanelHUD(
    batteryInfo: BatteryInfo,
    ramInfo: RamInfo,
    cpuUsagePct: Int,
    currentFps: Int,
    onCleanRam: () -> Unit,
    onToggleTurbo: () -> Unit,
    onToggleDnd: () -> Unit,
    onTakeScreenshot: () -> Unit,
    onCloseHud: () -> Unit,
    modifier: Modifier = Modifier
) {
    var installedFeatures by remember {
        mutableStateOf(
            listOf(
                HudFeature("clean_ram", "Clean RAM", Icons.Default.CleaningServices, isInstalled = true),
                HudFeature("turbo", "Turbo", Icons.Default.Speed, isInstalled = true),
                HudFeature("refresh", "Refresh Rate", Icons.Default.Tune, isInstalled = true),
                HudFeature("blok_notif", "Blok Notif", Icons.Default.NotificationsOff, isInstalled = true),
                HudFeature("screenshot", "Screenshot", Icons.Default.Screenshot, isInstalled = true),
                HudFeature("hemat_baterai", "Hemat Baterai", Icons.Default.EnergySavingsLeaf, isInstalled = true),
                HudFeature("crosshair", "Crosshair", Icons.Default.Adjust, isInstalled = true),
                HudFeature("resolusi", "Resolusi", Icons.Default.AspectRatio, isInstalled = true),
                HudFeature("suhu_alert", "Suhu Alert", Icons.Default.Thermostat, isInstalled = true),
                HudFeature("timer", "Timer Game", Icons.Default.Timer, isInstalled = true),
                HudFeature("monitor", "Monitor HUD", Icons.Default.Timeline, isInstalled = true),
                HudFeature("matikan", "Tutup Game", Icons.Default.PowerSettingsNew, isInstalled = true)
            )
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0x99000000))
            .clickable { onCloseHud() },
        contentAlignment = Alignment.Center
    ) {
        // Cockpit HUD Frame (Futuristik Transparan Sci-Fi)
        Box(
            modifier = Modifier
                .width(680.dp)
                .fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(24.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xEE091325), Color(0xEE050B15))
                    )
                )
                .border(1.5.dp, NeonCyan.copy(alpha = 0.7f), RoundedCornerShape(24.dp))
                .clickable(enabled = false) {} // Mencegah klik menembus ke latar belakang
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header HUD: Jam & Tombol Tutup Silang
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "◆ XARA HUD OVERLAY ◆",
                        style = MaterialTheme.typography.labelSmall.copy(color = NeonCyan, letterSpacing = 2.sp)
                    )

                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Color(0x33EF4444))
                            .clickable { onCloseHud() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Tutup", tint = DangerRed, modifier = Modifier.size(16.dp))
                    }
                }

                // Bagian Tengah: Gauge Radial FPS Besar + RAM + CPU
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // RAM Mini Gauge
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("RAM", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                        Text("${ramInfo.percentUsed}%", style = MaterialTheme.typography.titleMedium.copy(color = NeonCyan, fontWeight = FontWeight.Bold))
                        Box(
                            modifier = Modifier
                                .width(60.dp)
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(Color(0xFF1E293B))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(ramInfo.percentUsed / 100f)
                                    .background(NeonCyan)
                            )
                        }
                    }

                    // Gauge Radial FPS Pusat
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF0C172C))
                            .border(2.dp, if (currentFps < 45) Color(0xFFF97316) else NeonCyan, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("FPS", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
                            Text(
                                text = "$currentFps",
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 28.sp,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = if (currentFps < 45) "FPS DROP" else "STABIL",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (currentFps < 45) Color(0xFFF97316) else SuccessGreen,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }

                    // CPU Mini Gauge
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("CPU", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                        Text("$cpuUsagePct%", style = MaterialTheme.typography.titleMedium.copy(color = NeonCyan, fontWeight = FontWeight.Bold))
                        Box(
                            modifier = Modifier
                                .width(60.dp)
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(Color(0xFF1E293B))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(cpuUsagePct / 100f)
                                    .background(NeonCyan)
                            )
                        }
                    }
                }

                // Bagian Bawah: KATALOG FITUR (Grid 12 Tombol Aksi)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("KATALOG FITUR AKTIF", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                        Text("${installedFeatures.size}/12 TERPASANG", style = MaterialTheme.typography.labelSmall.copy(color = NeonCyan))
                    }

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(6),
                        modifier = Modifier.height(130.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(installedFeatures) { feat ->
                            Box(
                                modifier = Modifier
                                    .height(58.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(PillInactive)
                                    .border(1.dp, NeonCyan.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                                    .clickable {
                                        when (feat.id) {
                                            "clean_ram" -> onCleanRam()
                                            "turbo" -> onToggleTurbo()
                                            "blok_notif" -> onToggleDnd()
                                            "screenshot" -> onTakeScreenshot()
                                            else -> {}
                                        }
                                    }
                                    .padding(4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = feat.icon,
                                        contentDescription = feat.name,
                                        tint = NeonCyan,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = feat.name,
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = TextPrimary),
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
