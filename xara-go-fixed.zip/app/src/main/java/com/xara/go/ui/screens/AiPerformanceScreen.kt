package com.xara.go.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xara.go.ai.DecisionResult
import com.xara.go.ai.PerformanceProfile
import com.xara.go.hardware.BatteryInfo
import com.xara.go.hardware.RamInfo
import com.xara.go.ui.theme.*

@Composable
fun AiPerformanceScreen(
    batteryInfo: BatteryInfo,
    ramInfo: RamInfo,
    currentDecision: DecisionResult,
    isAutoEngineEnabled: Boolean,
    onToggleAutoEngine: (Boolean) -> Unit,
    onApplyNow: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Kolom Kiri: Sensor Hardware Masukan & Keputusan Profil
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(20.dp))
                .background(SurfaceCard)
                .border(1.dp, Color(0x2200E5FF), RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Memory,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "AI ENGINE PERFORMA",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        )
                    }

                    // Status Offline/Lokal
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0x2210B981))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "100% On-Device (Offline)",
                            style = MaterialTheme.typography.labelSmall.copy(color = SuccessGreen, fontSize = 9.sp)
                        )
                    }
                }

                // Sensor Feeds yang Dibaca AI
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("MASUKAN SENSOR SISTEM REAL-TIME", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(PillInactive)
                                .padding(8.dp)
                        ) {
                            Column {
                                Text("SUHU BATERAI", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = TextMuted))
                                Text(
                                    "${String.format("%.1f", batteryInfo.temperatureC)}°C",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = if (batteryInfo.temperatureC >= 42f) DangerRed else SuccessGreen)
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(PillInactive)
                                .padding(8.dp)
                        ) {
                            Column {
                                Text("PENGGUNAAN RAM", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = TextMuted))
                                Text(
                                    "${ramInfo.percentUsed}%",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = NeonCyan)
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(PillInactive)
                                .padding(8.dp)
                        ) {
                            Column {
                                Text("DAYA BATERAI", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = TextMuted))
                                Text(
                                    "${batteryInfo.percentage}%",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }

                // Kotak Profil Terpilih
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF090E17))
                        .border(1.dp, Color(currentDecision.profile.badgeColor).copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                        .padding(14.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("PROFIL REKOMENDASI AI", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(currentDecision.profile.badgeColor).copy(alpha = 0.2f))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = currentDecision.profile.displayName,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        color = Color(currentDecision.profile.badgeColor),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                )
                            }
                        }

                        Text(
                            text = currentDecision.headline,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        )

                        if (currentDecision.thermalWarning) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.Thermostat, contentDescription = null, tint = DangerRed, modifier = Modifier.size(16.dp))
                                Text("Peringatan Thermal: Risiko penurunan frame rate jika dipaksa", color = DangerRed, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        // Kolom Kanan: Alasan Keputusan & Kontrol Terapkan Otomatis
        Box(
            modifier = Modifier
                .weight(1.2f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(20.dp))
                .background(SurfaceCard)
                .border(1.dp, Color(0x2200E5FF), RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Switch Mode Otomatis
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(PillInactive)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Terapkan Otomatis", style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp, fontWeight = FontWeight.Bold))
                        Text("Evaluasi aturan setiap suhu atau status baterai berubah", style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted, fontSize = 10.sp))
                    }

                    Switch(
                        checked = isAutoEngineEnabled,
                        onCheckedChange = onToggleAutoEngine,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = DarkBgStart,
                            checkedTrackColor = NeonCyan
                        )
                    )
                }

                // Kotak Alasan Keputusan AI (Bahasa Indonesia Lengkap & Jelas)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF090E17))
                        .border(1.dp, Color(0x22334155), RoundedCornerShape(14.dp))
                        .padding(14.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                                Text(
                                    text = "ALASAN LOGIKA KEPUTUSAN",
                                    style = MaterialTheme.typography.labelSmall.copy(color = NeonCyan)
                                )
                            }

                            Text(
                                text = currentDecision.reasonIndonesian,
                                style = MaterialTheme.typography.bodyLarge.copy(color = TextPrimary, lineHeight = 20.sp)
                            )
                        }

                        // Target Setelan yang Ditentukan
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("TARGET KONFIGURASI:", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                            Text(
                                "• Refresh Rate: ${currentDecision.targetRefreshRate?.let { "${it} Hz" } ?: "Bawaan"}",
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary, fontSize = 11.sp)
                            )
                            Text(
                                "• Skala Animasi: ${currentDecision.targetAnimationScale}x",
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary, fontSize = 11.sp)
                            )
                            Text(
                                "• Game Mode: ${currentDecision.gameModeCommand.uppercase()}",
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary, fontSize = 11.sp)
                            )
                        }
                    }
                }

                // Tombol Terapkan Sekarang
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(NeonCyan)
                        .clickable { onApplyNow() }
                        .padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = DarkBgStart,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Terapkan Profil ${currentDecision.profile.displayName} Sekarang",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = DarkBgStart,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    )
                }
            }
        }
    }
}
