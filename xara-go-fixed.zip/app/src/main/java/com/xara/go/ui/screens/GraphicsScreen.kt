package com.xara.go.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xara.go.hardware.HardwareSpecs
import com.xara.go.ui.theme.*

@Composable
fun GraphicsScreen(
    hardwareSpecs: HardwareSpecs,
    selectedRefreshRate: Int,
    onSelectRefreshRate: (Int) -> Unit,
    colorSaturation: Float,
    onChangeSaturation: (Float) -> Unit,
    gameResolutionPct: Int,
    onChangeResolution: (Int) -> Unit,
    fpsLimit: Int,
    onSelectFpsLimit: (Int) -> Unit,
    gameMode: String, // standard, performance, battery
    onSelectGameMode: (String) -> Unit,
    isSustainedPerformance: Boolean,
    onToggleSustained: (Boolean) -> Unit,
    animScale: Float, // 1.0f, 0.5f, 0.0f
    onSelectAnimScale: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Kartu Kiri: GRAFIS
        Box(
            modifier = Modifier
                .weight(1.3f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(20.dp))
                .background(SurfaceCard)
                .border(1.dp, Color(0x2200E5FF), RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header Grafis
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "GRAFIS",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    )
                }

                // 1. Refresh Rate Selector
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Refresh rate", style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp))
                            val unsupportedRates = listOf(120, 144).filter { !hardwareSpecs.supportedRefreshRates.contains(it) }
                            if (unsupportedRates.isNotEmpty()) {
                                Text(
                                    text = "${unsupportedRates.joinToString(" & ")} Hz tidak didukung di HP ini",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted, fontSize = 10.sp)
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(60, 90, 120, 144).forEach { rate ->
                                val isSupported = hardwareSpecs.supportedRefreshRates.contains(rate)
                                val isSelected = selectedRefreshRate == rate

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isSelected) PillActive else PillInactive)
                                        .border(
                                            1.dp,
                                            if (isSelected) NeonCyan else Color.Transparent,
                                            RoundedCornerShape(10.dp)
                                        )
                                        .clickable(enabled = isSupported) { onSelectRefreshRate(rate) }
                                        .padding(horizontal = 14.dp, vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "$rate",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontSize = 12.sp,
                                            color = when {
                                                !isSupported -> Color(0xFF475569)
                                                isSelected -> NeonCyan
                                                else -> TextSecondary
                                            }
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                // 2. Saturasi Warna Slider [PREMIUM]
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Saturasi warna", style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp))
                            PremiumBadge()
                        }
                        Text(
                            text = "${String.format("%.1f", colorSaturation)}x",
                            style = MaterialTheme.typography.titleMedium.copy(color = NeonCyan, fontSize = 12.sp)
                        )
                    }

                    Slider(
                        value = colorSaturation,
                        onValueChange = onChangeSaturation,
                        valueRange = 0.8f..2.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFFFDE047),
                            activeTrackColor = Color(0xFFFDE047),
                            inactiveTrackColor = Color(0xFF334155)
                        )
                    )
                }

                // 3. Mode Warna (Tidak didukung di HP ini)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Mode warna", style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp))
                        Text("Tidak didukung di HP ini", style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted, fontSize = 10.sp))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Natural", "Cerah", "Kontras tinggi").forEach { mode ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(PillInactive.copy(alpha = 0.5f))
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(mode, style = MaterialTheme.typography.bodyMedium.copy(color = Color(0xFF475569), fontSize = 11.sp))
                            }
                        }
                    }
                }

                // 4. Resolusi Game Slider [Android 13+]
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Resolusi game", style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp))
                            PremiumBadge()
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0x2200E5FF))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("Android 13+", style = MaterialTheme.typography.labelSmall.copy(color = NeonCyan, fontSize = 9.sp))
                            }
                        }
                        Text(
                            text = if (gameResolutionPct == 100) "100% • Asli" else "$gameResolutionPct%",
                            style = MaterialTheme.typography.titleMedium.copy(color = NeonCyan, fontSize = 12.sp)
                        )
                    }

                    Slider(
                        value = gameResolutionPct.toFloat(),
                        onValueChange = { onChangeResolution(it.toInt()) },
                        valueRange = 50f..100f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFFFDE047),
                            activeTrackColor = Color(0xFFFDE047),
                            inactiveTrackColor = Color(0xFF334155)
                        )
                    )
                }

                // 5. Batas FPS (30, 60, 90, 120, Maks)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Batas FPS", style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp))

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(30, 60, 90, 120, 0).forEach { limit ->
                            val label = if (limit == 0) "Maks" else "$limit"
                            val isSelected = fpsLimit == limit

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) PillActive else PillInactive)
                                    .border(
                                        1.dp,
                                        if (isSelected) NeonCyan else Color.Transparent,
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable { onSelectFpsLimit(limit) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontSize = 11.sp,
                                        color = if (isSelected) NeonCyan else TextSecondary
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // Kartu Kanan: PERFORMA
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(20.dp))
                .background(SurfaceCard)
                .border(1.dp, Color(0x2200E5FF), RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header Performa
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "PERFORMA",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    )
                }

                // 1. Android Game Mode (cmd game mode)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Game Mode", style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            Triple("standard", "Standar", TextSecondary),
                            Triple("performance", "Performa", NeonCyan),
                            Triple("battery", "Hemat", SuccessGreen)
                        ).forEach { (modeKey, modeTitle, activeColor) ->
                            val isSelected = gameMode == modeKey

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) PillActive else PillInactive)
                                    .border(
                                        1.dp,
                                        if (isSelected) activeColor else Color.Transparent,
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable { onSelectGameMode(modeKey) }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = modeTitle,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontSize = 12.sp,
                                        color = if (isSelected) activeColor else TextSecondary
                                    )
                                )
                            }
                        }
                    }
                }

                // 2. Mode Performa Tetap (Kunci Clock)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Mode performa tetap", style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp))
                        Text("Kunci clock agar stabil", style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted, fontSize = 10.sp))
                    }

                    Switch(
                        checked = isSustainedPerformance,
                        onCheckedChange = onToggleSustained,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = DarkBgStart,
                            checkedTrackColor = NeonCyan
                        )
                    )
                }

                // 3. Animasi Sistem [PREMIUM]
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Animasi sistem", style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp))
                        PremiumBadge()
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            Pair(1.0f, "Normal"),
                            Pair(0.5f, "Cepat"),
                            Pair(0.0f, "Mati")
                        ).forEach { (scale, label) ->
                            val isSelected = animScale == scale

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) PillActive else PillInactive)
                                    .border(
                                        1.dp,
                                        if (isSelected) NeonCyan else Color.Transparent,
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable { onSelectAnimScale(scale) }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontSize = 12.sp,
                                        color = if (isSelected) NeonCyan else TextSecondary
                                    )
                                )
                            }
                        }
                    }
                }

                // Catatan footer (persis screenshot 1)
                Text(
                    text = "Semua setelan dikembalikan saat keluar dari game.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted, fontSize = 11.sp)
                )
            }
        }
    }
}

@Composable
fun PremiumBadge() {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF3B2713))
            .border(1.dp, Color(0xFFD97706), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = "PREMIUM",
            style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFFFDE68A), fontSize = 9.sp)
        )
    }
}
