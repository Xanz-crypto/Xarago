package com.xara.go.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBgStart = Color(0xFF040810)
val DarkBgMid = Color(0xFF060B16)
val DarkBgEnd = Color(0xFF0A1020)

val SurfaceCard = Color(0xCC0D1524)
val SurfaceCardBorder = Color(0x4000E5FF)
val SurfaceCardMuted = Color(0x99111C2E)

val NeonCyan = Color(0xFF00E5FF)
val NeonCyanGlow = Color(0x3300E5FF)
val NeonPurple = Color(0xFF8B5CF6)
val NeonPurpleGlow = Color(0x338B5CF6)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val DangerRed = Color(0xFFEF4444)
val SuccessGreen = Color(0xFF10B981)
val WarningYellow = Color(0xFFF59E0B)

val PillInactive = Color(0xFF162032)
val PillActive = Color(0xFF1A3348)
